import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

/**
 * This class runs the Program
 */
public class Main {
    /**
     * This variable counts as the counter for the days.
     */
    public static int currentDay = 1;
    /**
     * Arranges the Tile class into a 2d ArrayList
     */
    public static ArrayList<ArrayList<Tile>> tiles = new ArrayList<>();
    public static Player player = new Player();
    /**
     * initializes the Scanner Class
     */
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Enter Name :");
        String name = sc.next();
        player = new Player(name);
        int totalRows = 1;
        int totalColumns = 1;
        initTiles(totalRows, totalColumns);
        drawGrid();
        while (player.coins > 0) {

            System.out.println("Do you wish to commit an action (Y/N)");
            char answer = sc.next().charAt(0);
            while (answer != 'y' && answer != 'Y' & answer != 'n' & answer != 'N') {
                System.out.println("Invalid input please re-input");
                answer = sc.next().charAt(0);
            }
            while (answer == 'y' || answer == 'Y') {
                tileAction();
                drawGrid();
                System.out.println("Do you wish to commit an action (Y/N)");
                answer = sc.next().charAt(0);
                while (answer != 'y' && answer != 'Y' && answer != 'n' && answer != 'N') {
                    System.out.println("Invalid input please re-input");
                    answer = sc.next().charAt(0);
                }
            }
            currentDay++;
            System.out.println("Now Entering Day " + currentDay);
            drawGrid();
        }
        System.out.println("YOU ARE NOW BANKRUPT, YOU LOSE!");
    }

    /**
     * Initializes the Tiles Arraylist into an n x n  grid
     *
     * @param totalRows    the amount of rows in the grid
     * @param totalColumns the amount of columns in the grid
     */
    public static void initTiles(int totalRows, int totalColumns) {
        for (int i = 0; i < totalRows; i++) {
            tiles.add(new ArrayList<>());
        }
        for (ArrayList<Tile> tile : tiles) {
            for (int j = 0; j < totalColumns; j++) {
                tile.add(new Tile());
            }
        }

    }

    /**
     * draws the grid of tiles
     */
    public static void drawGrid() {
        int i;
        StringBuilder Buffer = new StringBuilder();
        StringBuilder columnLegend = new StringBuilder("  ");
        checkPlantStats();
        player.checkLevel();
        for (i = 0; i < 11 * tiles.get(0).size() + 2; i++) {
            Buffer.append("-");
        }
        for (i = 0; i < tiles.get(0).size(); i++) {
            columnLegend.append(String.format("|%5d%4s|", i + 1, ""));
        }
        System.out.printf("%s %3sCoins: %d %3s Current Day: %d %3s Level %d\n", player.name, "", player.coins, "", currentDay, "", player.level);
        System.out.printf("%s\n%s\n%s\n", Buffer, columnLegend, Buffer);

        for (i = 0; i < tiles.size(); i++) {
            System.out.printf("%2d", i + 1);
            for (int j = 0; j < tiles.get(i).size(); j++) {
                if (tiles.get(i).get(j).hasCrop) {
                    System.out.printf("|%8s |", tiles.get(i).get(j).Crop.name);
                } else if (tiles.get(i).get(j).isPlowed) {
                    System.out.printf("|%8s |", "Plowed");
                } else {
                    System.out.printf("|%8s |", "");
                }
            }
            System.out.println();
            System.out.println(Buffer);

        }

    }

    /**
     * uses a for loop to check call the checkPlantStats method in each tile object
     */
    public static void checkPlantStats() {
        for (int i = 0; i < tiles.size(); i++) {
            for (int j = 0; j < tiles.get(i).size(); j++) {
                if (tiles.get(i).get(j).hasCrop) {
                    tiles.get(i).get(j).Crop.checkPlantStats(currentDay);

                    if (tiles.get(i).get(j).Crop.isWithered) {
                        if (!Objects.equals(tiles.get(i).get(j).Crop.name, "withered")) {
                            System.out.printf("The %s in row %d column %d withered\n", tiles.get(i).get(j).Crop.name, i + 1, j + 1);
                            tiles.get(i).get(j).Crop = new Crop("withered");
                        }
                    }
                    if (tiles.get(i).get(j).Crop.isHarvestable) {
                        System.out.printf("The %s in row %d column %d is harvestable\n", tiles.get(i).get(j).Crop.name, i + 1, j + 1);
                    }
                }

            }
        }
    }

    /**
     * shows choices in which the user can do actions in a tile
     */
    public static void tileAction() {

        Scanner sc = new Scanner(System.in);
        int row, column, choice;
        System.out.println("Enter Which Slot will you will you interact with (row column)");
        row = sc.nextInt();
        column = sc.nextInt();
        while (row > tiles.size() || row < 0) {
            System.out.println("Invalid row input please re-input");
            row = sc.nextInt();
        }
        while (column > tiles.get(0).size() || column < 0) {
            System.out.println("Invalid column input please re-input");
            column = sc.nextInt();
        }

        System.out.print("Which action will you do\n1. Plow\n2. Water\n3. Fertilize \n4. Plant\n5. Harvest\n6. Check plant\n");
        choice = sc.nextInt();
        while (choice > 6 || choice < 0) {
            System.out.println("Invalid input please re-input");
            while (sc.hasNextInt()) {
                choice = sc.nextInt();
            }
        }
        switch (choice) {
            case 1 -> tiles.get(row - 1).get(column - 1).plowTile(player, row, column);
            case 2 -> tiles.get(row - 1).get(column - 1).waterCrop(player, row, column);
            case 3 -> tiles.get(row - 1).get(column - 1).fertilizeCrop(player, row, column);
            case 4 -> tiles.get(row - 1).get(column - 1).plantCrop(player, currentDay);
            case 5 -> tiles.get(row - 1).get(column - 1).harvestCrop(player, row, column);
            case 6 -> tiles.get(row - 1).get(column - 1).getCropStats(currentDay);
        }


    }
}
