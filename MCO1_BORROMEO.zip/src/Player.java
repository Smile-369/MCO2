public class Player {
    public int coins;
    public int level;
    public float experience;
    public String name;

    public Player() {

    }

    /**
     * Initializes the starting values of the player and sets the player's name based on input
     *
     * @param name name of the player
     */
    public Player(String name) {
        this.coins = 100;
        this.level = 0;
        this.experience = 0;
        this.name = name;
    }

    /**
     * checks and calculates the level of the player based the experience value
     */
    public void checkLevel() {
        int originalLevel = this.level;
        char temp = String.format("%03d", (int) this.experience).charAt(0);
        this.level = Integer.parseInt(String.valueOf(temp));
        if (originalLevel != this.level) {
            System.out.println("Congratulations your level changed from " + originalLevel + " to " + this.level);
        }
    }
}
